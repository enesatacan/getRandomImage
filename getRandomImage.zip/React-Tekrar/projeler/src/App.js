import "./App.css";
import { Typography, Button, Stack } from "@mui/material";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RandomImagesProject from "./Components/RandomImagesProject/Main";
import ApiCall from "./Components/apiCall/Main";
import JiraApplication from "./Components/JiraApplication/Main";
import BodyFinding from "./Components/BodyFinding/Main";
import NumberPrediction from "./Components/numberPrediction/App";

function App() {
  return (
    <Router>
      <Stack textAlign={"center"} mb={5}>
        <div className="App">
          <Typography variant="h5" my={5}>
            Click on the Project You Want to Review
          </Typography>
          <Stack spacing={2}>
            <Link to="/">
              <Button variant="outlined">Reset</Button>
            </Link>
            <Link to="/randomImagesProject">
              <Button variant="contained">Random Images Project</Button>
            </Link>
{/* 
            <Link to="/apiCall">
              <Button variant="contained">Api Call</Button>
            </Link>
            <Link to="/jiraApplication">
              <Button variant="contained">Jira Application</Button>
            </Link>
            <Link to="/body">
              <Button variant="contained">Body Finding</Button>
            </Link>
            <Link to="/prediction">
              <Button variant="contained">Number Prediction</Button>
            </Link> */}
          </Stack>
        </div>
      </Stack>

      <Routes>
        <Route path="/randomImagesProject" element={<RandomImagesProject />} />
        {/* <Route path="/apiCall" element={<ApiCall />} />
        <Route path="/JiraApplication" element={<JiraApplication />} />
        <Route path="/body" element={<BodyFinding />} />
        <Route path="/prediction" element={<NumberPrediction />} /> */}
      </Routes>
    </Router>
  );
}

export default App;
