import React from "react";
import imagesOne from "./Images/imagesOne.jpg";
import imagesTwo from "./Images/imagesTwo.jpg";
import imagesThree from "./Images/imagesThree.jpg";
import imagesFour from "./Images/imagesFour.jpg";

function Images({ imageNumber }) {
  const imagesMap = {
    imagesOne,
    imagesTwo,
    imagesThree,
    imagesFour,
  };
  console.log(imagesMap[imageNumber]);
  return (
    <div>
      <img
        style={{
          width: "350px",
          height: "auto",
          borderRadius: "36px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
          margin: 5,
          display: "flex",
          justifyContent: "center",
        }}
        src={imagesMap[imageNumber]}
        alt="Random Images"
      />
    </div>
  );
}

export default Images;
