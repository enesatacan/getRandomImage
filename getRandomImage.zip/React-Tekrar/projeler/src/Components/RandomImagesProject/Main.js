import React from "react";
import { useState } from "react";
import Images from "./Images";
import { Typography, Button, Card, Stack } from "@mui/material";

function Main() {
  const getRandomImages = () => {
    const imagesArray = ["imagesOne", "imagesTwo", "imagesThree", "imagesFour"];
    return imagesArray[Math.floor(Math.random() * imagesArray.length)];
  };
  const [images, setImages] = useState([]);
  const handleClick = () => {
    setImages([...images, getRandomImages()]);
  };
  const imageList = images.map((image, index) => {
    return <Images key={index} imageNumber={image} />;
  });

  return (
    <div>
      <Card>
        <Button
          variant="outlined"
          sx={{ marginLeft: 5, marginTop: 2 }}
          onClick={handleClick}
        >
          Get Images
        </Button>

        <Stack m={5} spacing={2}>
          <Typography>
            To view the photos randomly, please click on the get images button
          </Typography>
          <Typography>
            This project aims to display one of four photos from a photo pool
            randomly by clicking a button.
          </Typography>

          <Typography>
            The photos are stored in an array, and random index numbers are
            generated using the Math.random() and Math.floor() methods. The
            photo corresponding to the generated index is then displayed on the
            screen sequentially using useState in combination with the spread
            operator.
          </Typography>
        </Stack>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            flexWrap: "wrap",
          }}
        >
          {imageList}
        </div>
      </Card>
    </div>
  );
}

export default Main;
